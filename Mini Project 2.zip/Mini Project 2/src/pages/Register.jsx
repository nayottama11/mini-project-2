import React, { useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import "./Register.css";

const Register = () => {
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [roleid, setRoleId] = useState(null)

  async function signUp(){
    let item={name, username, password, roleid}
    console.warn(item);

    let result= await fetch("https://api.mudoapi.tech/register", {
      method: 'POST', 
      body:JSON.stringify(item),
      headers:{
        "Content-Type": 'application/json',
        "Accept": 'application/json'
      }
    })
    result = await result.json();
    console.warn("result", result);
  }

  const handleChangeName = (e) => {
    setName(e.target.value);
  };

  const handleChangeUsername = (e) => {
    setUsername(e.target.value);
  };

  const handleChangePass = (e) => {
    setPassword(e.target.value);
  };

  const handleChangeRoleId = (e) => {
    setRoleId(e.target.value);
  };
  

  const handleSubmit = () => {
    const payload = {
      name: name,
      username: username,
      password: password,
      roleid: roleid,
    };
  
    axios
      .post("https://api.mudoapi.tech/register", payload)
      .then((res) => {
        console.log(res);
        navigate("/");
        localStorage.setItem("token", "abcdefg");
      })
      .catch((err) => {
        console.log(err);
      });
  };

  console.log("payload", name, username, password, roleid)

  const navigate = useNavigate();

  return (
    <div className="container">
      <div className="header">
        <h1 style={{color: "#fff"}} >Register</h1>
      </div>
      <div className="inputs">
      <div className="input">
          <input onChange={handleChangeName} placeholder="Name" />
        </div>
        <div className="input">
          <input onChange={handleChangeUsername} placeholder="Username" />
        </div>
        <div className="input">
          <input onChange={handleChangePass} placeholder="Password" />
        </div>
        <div className="input">
          <input onChange={handleChangeRoleId} placeholder="RoleID" />
        </div>
      </div>
      <div className="login-container">
        <button className="login" onClick={signUp}>
          Sign Up
        </button>
        <div>
        <p>Already have an account?</p>
        <Link to={"/login"}><p>Login</p></Link>
      </div>
      </div>
    </div>
  );
};

export default Register;
