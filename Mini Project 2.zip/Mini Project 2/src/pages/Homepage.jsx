import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import Navbar from "../components/Navbar";
import "./Menu.css";


const Homepage = () => {
  const [menus, setMenus] = useState([]);
  const [search, setSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const navigate = useNavigate();

  const getMenus = () => {
    axios
      .get(`https://api.mudoapi.tech/menus?perPage=9&page=${currentPage}&name=${search}`)
      .then((res) => {
        const data = res?.data?.data?.Data;
        setMenus(data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleDetail = (id) => {
    navigate(`/detail/${id}`);
  };

  const handleChangeSearch = (e) => {
    setSearch(e.target.value);
  };

  const handleDelete = (id) => {
    const token = localStorage.getItem("token");

    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    };

    axios
      .delete(`https://api.mudoapi.tech/menu/${id}`, config)
      .then((res) => {
        console.log(res);
        getMenus();
      })
      .catch((err) => {
        console.log(err);
      });
  };

  useEffect(() => {
    getMenus();
  }, [search, currentPage]);
  return (
    <div>
      <Navbar />
      <div className="menu">
        <h1 className="menuTitle">Our Menu</h1>
        <input style={{ marginBottom: "40px", borderRadius: "40px"}} onChange ={handleChangeSearch} />
        <div className="menuList">
        {menus.map((item, key) => (
        <div className="card" key={key} style={{ marginBottom: "40px" }}>
          <img className="card-img-top"  src={item?.imageUrl} />
          <div className="overlay">
            <div className="text">Hellow</div>
          </div>
          <div className="card-body">
          <h3 className="card-text" >{item.name}</h3>
          <p>{item.description}</p>
          <button className="btn-primary" onClick={() => handleDetail(item.id)}>Detail</button>
          </div>
        </div>
      ))}
        </div>
      </div>
      
      <div className="pagination center">
        {currentPage > 1 ? (
          <button className="btn-primary" onClick={() => setCurrentPage(currentPage - 1)}>
            Prev page
          </button>
        ) : null}

        <button className="btn-primary" onClick={() => setCurrentPage(currentPage + 1)}>
          Next Page
        </button>
      </div>
    </div>
  );
};

export default Homepage;
