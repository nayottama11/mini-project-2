import React, { useState } from "react";
import axios from "axios";
import "./Login.css";
import { Link, useNavigate } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleChangeEmail = (e) => {
    setEmail(e.target.value);
  };

  const handleChangePass = (e) => {
    setPassword(e.target.value);
  };

  const handleSubmit = () => {
    const payload = {
      username: email,
      password: password,
    };
  
    axios
      .post("https://api.mudoapi.tech/login", payload)
      .then((res) => {
        console.log(res);
        localStorage.setItem("token", "abcdefg");
        navigate("/")
      })
      .catch((err) => {
        
        console.log(err);
      });
  };

  console.log("payload", email, password);

  const navigate = useNavigate();

  return (
    <div className="container">
      
      <div className="header">
        <h1 style={{color: "#fff"}} >Login</h1>
      </div>
      <div className="inputs">
        <div className="input">
          <input
            onChange={handleChangeEmail}
            placeholder="Username"
          />
        </div>
        <div className="input">
          <input
            onChange={handleChangePass}
            placeholder="Password"
          />
        </div>
      </div>
      <div className="login-container">
        <button className="login" onClick={handleSubmit}>Login</button>
      </div>
      <div className="login-container">
        <p>Dont have an account?</p>
        <Link to={"/register"}><p>Register</p></Link>
      </div>
    </div>
  );
};

export default Login;
